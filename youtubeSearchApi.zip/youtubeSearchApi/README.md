commands to run the project

npm install
npm start

the open url -->  http://localhost:8080

Application uses youtube search api for retreving data.
